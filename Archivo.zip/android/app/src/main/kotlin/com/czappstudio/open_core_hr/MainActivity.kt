package com.czappstudio.open_core_hr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
