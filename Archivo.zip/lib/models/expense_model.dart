class ExpenseModel {
  int? id;
  String? type;
  String? status;
  num? amount;
  String? date;

  ExpenseModel(this.id, this.type, this.status, this.amount, this.date);
}
