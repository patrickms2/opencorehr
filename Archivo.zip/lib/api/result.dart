class Result {
  bool isSuccess = false;
  String message = '';
}
