// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'forms_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic, no_leading_underscores_for_local_identifiers

mixin _$FormsStore on FormsStoreBase, Store {
  late final _$isLoadingAtom =
      Atom(name: 'FormsStoreBase.isLoading', context: context);

  @override
  bool get isLoading {
    _$isLoadingAtom.reportRead();
    return super.isLoading;
  }

  @override
  set isLoading(bool value) {
    _$isLoadingAtom.reportWrite(value, super.isLoading, () {
      super.isLoading = value;
    });
  }

  late final _$isBtnLoadingAtom =
      Atom(name: 'FormsStoreBase.isBtnLoading', context: context);

  @override
  bool get isBtnLoading {
    _$isBtnLoadingAtom.reportRead();
    return super.isBtnLoading;
  }

  @override
  set isBtnLoading(bool value) {
    _$isBtnLoadingAtom.reportWrite(value, super.isBtnLoading, () {
      super.isBtnLoading = value;
    });
  }

  @override
  String toString() {
    return '''
isLoading: ${isLoading},
isBtnLoading: ${isBtnLoading}
    ''';
  }
}
